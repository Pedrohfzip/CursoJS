//String aspas duplas 
console.log("String aspas duplas")
//String simples
console.log('string simples')
//String tamplate literals
console.log(`string template literals`)