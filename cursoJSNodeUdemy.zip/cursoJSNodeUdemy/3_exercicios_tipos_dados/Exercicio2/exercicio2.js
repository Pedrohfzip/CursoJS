console.log(10)
console.log(10.30)
console.log(10 + 20)
