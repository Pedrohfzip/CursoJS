console.log(5 / `Pedro`)
