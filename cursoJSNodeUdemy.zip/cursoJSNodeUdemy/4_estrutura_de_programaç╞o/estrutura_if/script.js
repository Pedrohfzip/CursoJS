let idade = 17;
if(idade > 18){
    console.log(`Pode entrar`)
}else{
    console.log(`Não pode entrar`)
}