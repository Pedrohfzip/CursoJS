//prompt
//let idade = prompt("Escreve sua idade");
//console.log(`A idade é ${idade}`)
//alert
//alert(`A idade é ${idade}`)
//Math
let maior = Math.fround(143.1232)
console.log(maior)