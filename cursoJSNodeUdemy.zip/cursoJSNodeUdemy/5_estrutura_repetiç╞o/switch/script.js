let nome = "Pedro"
switch(nome){
    case "Joao":
        console.log("O nome é joão")
        break;
    case "Pedro":
        console.log("O nome é pedro")
        break;
    default: 
        console.log("O nome não é Joao nem Pedro")
        break;
}
