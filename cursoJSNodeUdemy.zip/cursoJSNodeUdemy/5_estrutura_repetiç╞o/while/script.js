let x = 10;
while( x > 0){
    console.log(x)
    x = x - 1
}