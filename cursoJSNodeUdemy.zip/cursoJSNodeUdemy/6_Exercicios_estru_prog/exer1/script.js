let nome = `Pedro`
let numero = 10;
let verdadeiro = true;
console.log(typeof `${nome}`)
console.log(typeof numero)