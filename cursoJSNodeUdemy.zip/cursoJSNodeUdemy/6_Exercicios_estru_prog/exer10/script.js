let x = 1;
for(let i;i<=50;i++){

    if(x % i == x && x % i == 1){
        console.log(`${x} é primo`)
    }else{
        console.log(`${x} não é primo`)
    }
    
}
