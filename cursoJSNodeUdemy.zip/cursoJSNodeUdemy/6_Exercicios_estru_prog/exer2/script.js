let idade = 17;
if(idade > 18){
    console.log(`Pode entrar`)
}else{
    console.log(`Não Pode entrar, é de menor`)
}