const nome = "Pedro"
if(nome == "Pedro"){
    console.log("Ola Pedro")
}else{
    console.log("Ola anonimo")
}