let velocidade = 90;
if(velocidade > 80){
    console.log("O carro esta a cima da velocidade, reduza!")
}else{
    console.log("Mantenha essa velocidar para baixo")
}