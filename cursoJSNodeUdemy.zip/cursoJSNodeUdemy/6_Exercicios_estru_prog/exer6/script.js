let idade = 18;
let cnh = true;
if(idade >= 18 && cnh == true){
    console.log("É permitido dirigir")
}else{
    console.log("Não pode dirigir")
}