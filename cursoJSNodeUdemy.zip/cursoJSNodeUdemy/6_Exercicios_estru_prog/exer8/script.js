let x = 100
/*
while(x > 50){
    x--
    console.log(x)
}
*/
for(x;x >= 50;x--){
    console.log(x)
}