let x = 0;
for(x;x<=50;x++){
    if(x % 2 == 0){
        console.log(`${x} é par`)
    }else if(x % 2 == 1){
        console.log(`${x} é impar`)
    }
}