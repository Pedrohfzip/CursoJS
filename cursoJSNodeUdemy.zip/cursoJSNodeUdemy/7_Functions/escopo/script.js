let x = 10
function mostrar(){
    let x = 20;
    console.log(x)
}

mostrar()
console.log(x)