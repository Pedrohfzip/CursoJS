let y = 5;

const primeiroEscopo = function(x){
    let y = x + 1;
    console.log(y)
        if(y > 10){
            let y = 100
            console.log(y)
        }
}

primeiroEscopo(10)