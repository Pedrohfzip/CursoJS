function escreverNoConsole(){
    console.log("Escrevendo no console!")
}

escreverNoConsole();

const textoNoConsole = function(){
    console.log("Texto no console!")
}

textoNoConsole();

const textPorparametro = function(texto){
    console.log(texto)
}

textPorparametro("Teste parametro")