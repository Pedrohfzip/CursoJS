"use strict"

let opa = 'teste';

// delete Object.prototype;

function teste() {
  "use strict"
  let testando = 'teste';
}

teste();

// false.prop = "";
// "teste".prop = "";
