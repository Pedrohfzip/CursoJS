const digitos = /\d+/;

console.log(digitos.exec("Tem o número 100 aqui"));
console.log(digitos.exec("Tem o número aqui"));

