console.log(document.getElementsByTagName('h1'));

console.log(document.getElementById('titulo-principal'));