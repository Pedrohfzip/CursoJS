console.log(document.querySelector('#container-principal h1'));

console.log(document.querySelector('#segundo-container h1'));

console.log(document.querySelector('div div p'));

console.log(document.querySelector('footer h2'));

console.log(document.querySelector('ul .itens-azuis'));