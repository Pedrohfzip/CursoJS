window.addEventListener("mousemove", function(e) {

  console.log(e.x);
  console.log(e.y);

});