window.addEventListener("scroll", function(e) {

  if(window.pageYOffset > 1000) {
    console.log("Ativou");
  }

});