console.log("Hello World!");
console.log('Meu nome é Matheus');
console.log(`Este aqui é o template literals`);