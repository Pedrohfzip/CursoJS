let nome = "Matheus";
let idade = 28;

if(nome != undefined && nome == "Joaquim") {
  console.log("Nome está definido");
} else if(nome == "Matheus" && nome.length > 5 && idade == 50) {
  console.log("O nome é Matheus");
} else {
  console.log("Não é Matheus!");
}

if(1 > 2) {
  console.log("Teste");
} else if(1 == 1) {
  console.log("Testando");
}