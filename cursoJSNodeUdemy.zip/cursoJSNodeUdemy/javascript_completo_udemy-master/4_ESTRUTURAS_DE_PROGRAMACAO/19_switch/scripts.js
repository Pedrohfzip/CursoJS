let nome = "Matheus";

switch(nome) {
  case "Matheus":
    console.log("O Nome é Matheus");
    break;
  case "João":
    console.log("O nome é João");
    break;
  default:
    console.log("O nome não foi encontrado");
    break;
}

// if(nome == "Matheus") {
//   console.log("O Nome é Matheus");
// } else {
//   console.log("O nome não foi encontrado");
// }