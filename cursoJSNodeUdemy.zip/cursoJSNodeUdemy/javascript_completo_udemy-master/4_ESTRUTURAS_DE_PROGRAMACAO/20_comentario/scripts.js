// COmentário de uma linha

/*
  Comentário
  de
  múltiplas
  linhas
*/

// console.log("Teste");