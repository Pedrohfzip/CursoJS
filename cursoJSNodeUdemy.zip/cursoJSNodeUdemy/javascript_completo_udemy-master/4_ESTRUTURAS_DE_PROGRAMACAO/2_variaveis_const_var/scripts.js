var nome = "Matheus";
const ip = "127.0.0.1";

console.log(nome);
console.log(ip);

ip = 'asdihus';