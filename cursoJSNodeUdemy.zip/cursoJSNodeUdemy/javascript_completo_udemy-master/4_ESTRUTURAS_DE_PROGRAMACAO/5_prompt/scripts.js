let idade = prompt("Qual a sua idade?");

console.log(idade);

let nome = prompt("Qual o seu nome?");

console.log(`O seu nome é ${nome}`);