alert("Esta é a mensagem!");
alert("Esta é a mensagem 2!");