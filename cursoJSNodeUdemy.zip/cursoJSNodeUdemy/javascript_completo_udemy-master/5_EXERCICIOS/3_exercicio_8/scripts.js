const nome = "Matheus";

if(nome == "Matheus") {
  console.log(`Olá ${nome}, tudo bem?`);
}