function imprimirNoConsole() {
  console.log("Hello World!");
}

imprimirNoConsole();