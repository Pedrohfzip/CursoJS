function imprimeIdade(idade) {
  console.log(`Você tem ${idade} anos`);
}

imprimeIdade(12);
imprimeIdade(28);
imprimeIdade(45);