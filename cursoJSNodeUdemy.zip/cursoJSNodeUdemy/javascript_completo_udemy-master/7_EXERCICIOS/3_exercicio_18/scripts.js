function soma(a,b) {
  return a + b;
}

console.log(soma(4,5));
console.log(soma(10,20));