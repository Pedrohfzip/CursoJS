let arr = [1, 4, 5, 6, 7];
let nomes = ['Matheus', 'João', 'Aléxia'];
let bool = [true, false, true];

console.log(arr[1]);
console.log(nomes[0]);
console.log(bool[2]);
console.log(arr[arr.length - 1]);

