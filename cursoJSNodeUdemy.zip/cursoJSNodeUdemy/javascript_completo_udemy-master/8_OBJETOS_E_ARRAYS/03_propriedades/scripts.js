let nome = "João";

console.log(nome.length);

let numeros = [1,23,34,5,6,7,8];

console.log(numeros.length);
console.log(numeros['length']);
console.log(numeros[1]);
