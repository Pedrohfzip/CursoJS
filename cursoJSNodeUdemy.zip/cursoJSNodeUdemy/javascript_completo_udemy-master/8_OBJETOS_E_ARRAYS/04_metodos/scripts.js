let marca = 'nike';

console.log(marca.toUpperCase());

let marca2 = marca.toUpperCase();

console.log(marca2.toLowerCase());

console.log(typeof marca2.toLowerCase);


// string.propriedade
// string.metodo()
