let nomes = ["Matheus", "Maria", "José"];

for(let i = 0; i <= nomes.length; i++) {
  console.log(nomes[i]);
}
