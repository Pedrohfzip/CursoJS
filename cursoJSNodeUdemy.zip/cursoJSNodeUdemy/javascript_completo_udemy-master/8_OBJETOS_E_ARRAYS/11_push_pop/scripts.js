let nomes = ["Matheus", "Maria", "José"];

let elementoRemovido = nomes.pop();

console.log(elementoRemovido);
console.log(nomes);

nomes.push('Pedro');

console.log(nomes);