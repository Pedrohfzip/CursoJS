let nums = [5,6,2,4,9,6,2];

console.log(nums.indexOf(2));

console.log(nums.lastIndexOf(2));