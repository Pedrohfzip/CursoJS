let nomes = ["Matheus", "Maria", "José", "Pedro", "João"];

nomes.forEach(nome => {
  console.log("O nome é " + nome);
});

// nomes[i]