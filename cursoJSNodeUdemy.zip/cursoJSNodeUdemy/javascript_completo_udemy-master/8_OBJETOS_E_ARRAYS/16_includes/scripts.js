let carros = ["BMW", "Fiat", "VW", "Renault", "Audi"];

console.log(carros.includes("Fiat"));
console.log(carros.includes("Ford"));

// if(carros.includes("BMW")) {}