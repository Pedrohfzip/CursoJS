let nome = " \n   Matheus \n ";

// Olá     Matheus , tudo bem?

let nomeCorrigido = nome.trim();

console.log(nome);
console.log(nomeCorrigido);
