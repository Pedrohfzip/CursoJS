let sku = "34";

console.log(sku.padStart(6, "0"));

let sku2 = "7348";

console.log(sku2.padStart(6, "0"));
