let numeros = [2,4,5,8];

let [num1, num2, num3, num4] = numeros;

console.log(num1);
console.log(num3);