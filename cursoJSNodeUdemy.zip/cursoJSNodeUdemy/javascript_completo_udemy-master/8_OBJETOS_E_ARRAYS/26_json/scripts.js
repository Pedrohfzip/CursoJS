let pessoa = {
  "nome": "Matheus",
  "idade": 28
}

console.log(pessoa.nome);
console.log(pessoa.idade);