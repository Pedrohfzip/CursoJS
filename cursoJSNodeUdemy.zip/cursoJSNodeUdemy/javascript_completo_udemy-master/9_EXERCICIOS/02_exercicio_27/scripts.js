let nomes = ["Matheus", "João"];
let testes = [true, false, true, true];

console.log(nomes.length);
console.log(testes.length);