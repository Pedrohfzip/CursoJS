let pessoa = {
  "name": "Matheus",
  "age": 28,
  "role": "Programador"
}

console.log(pessoa.name);
console.log(pessoa.age);
console.log(pessoa.role);